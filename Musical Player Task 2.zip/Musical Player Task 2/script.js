const audioPlayer = document.getElementById('audioPlayer');
const fileInput = document.getElementById('fileInput');
const playlist = document.getElementById('playlist');
const playBtn = document.getElementById('playBtn');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const volumeControl = document.getElementById('volumeControl');
const searchInput = document.getElementById('searchInput');
const themeBtn = document.getElementById('theme-btn');

let currentSongIndex = 0;
let songs = [];

fileInput.addEventListener('change', (e) => {
  songs = Array.from(e.target.files);
  playlist.innerHTML = '';
  songs.forEach((song, i) => {
    const li = document.createElement('li');
    li.textContent = song.name;
    li.addEventListener('click', () => playSong(i));
    playlist.appendChild(li);
  });
  if (songs.length > 0) playSong(0);
});

function playSong(index) {
  if (!songs[index]) return;
  currentSongIndex = index;
  const fileURL = URL.createObjectURL(songs[index]);
  audioPlayer.src = fileURL;
  audioPlayer.play();
}

playBtn.addEventListener('click', () => {
  if (audioPlayer.paused) {
    audioPlayer.play();
    playBtn.textContent = '⏸️ Pause';
  } else {
    audioPlayer.pause();
    playBtn.textContent = '▶️ Play';
  }
});

nextBtn.addEventListener('click', () => {
  currentSongIndex = (currentSongIndex + 1) % songs.length;
  playSong(currentSongIndex);
});

prevBtn.addEventListener('click', () => {
  currentSongIndex = (currentSongIndex - 1 + songs.length) % songs.length;
  playSong(currentSongIndex);
});

volumeControl.addEventListener('input', () => {
  audioPlayer.volume = volumeControl.value;
});

searchInput.addEventListener('input', () => {
  const searchTerm = searchInput.value.toLowerCase();
  const items = playlist.getElementsByTagName('li');
  Array.from(items).forEach(li => {
    li.style.display = li.textContent.toLowerCase().includes(searchTerm) ? '' : 'none';
  });
});

// 🌗 Dark/Light mode toggle
themeBtn.addEventListener('click', () => {
  document.body.classList.toggle('light-mode');
  if (document.body.classList.contains('light-mode')) {
    themeBtn.textContent = '🌞 Light Mode';
  } else {
    themeBtn.textContent = '🌙 Dark Mode';
  }
});

// 🎈 Animated bubbles background
const canvas = document.getElementById('bubbles');
const ctx = canvas.getContext('2d');
let bubbles = [];

function resizeCanvas() {
  canvas.width = window.innerWidth;
  canvas.height = window.innerHeight;
}
resizeCanvas();
window.addEventListener('resize', resizeCanvas);

class Bubble {
  constructor() {
    this.x = Math.random() * canvas.width;
    this.y = canvas.height + Math.random() * 100;
    this.radius = 5 + Math.random() * 15;
    this.speed = 1 + Math.random() * 3;
    this.alpha = 0.3 + Math.random() * 0.7;
  }
  update() {
    this.y -= this.speed;
    if (this.y + this.radius < 0) {
      this.y = canvas.height + this.radius;
      this.x = Math.random() * canvas.width;
    }
  }
  draw() {
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.radius, 0, Math.PI * 2);
    ctx.fillStyle = `rgba(173, 83, 137, ${this.alpha})`;
    ctx.fill();
  }
}

for (let i = 0; i < 40; i++) bubbles.push(new Bubble());

function animate() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  bubbles.forEach(b => {
    b.update();
    b.draw();
  });
  requestAnimationFrame(animate);
}
animate();
