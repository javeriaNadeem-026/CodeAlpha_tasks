function calculateAge() {
  const day = document.getElementById("day").value;
  const month = document.getElementById("month").value;
  const year = document.getElementById("year").value;
  const result = document.getElementById("result");

  // clear previous result
  result.innerHTML = "";

  // check if inputs are valid
  if (!day || !month || !year) {
    result.innerHTML = `<div class="error"><span>⚠️</span>Please enter complete date of birth!</div>`;
    return;
  }

  // create birth date object
  const birthDate = new Date(year, month - 1, day);
  const today = new Date();

  // invalid future date
  if (birthDate > today) {
    result.innerHTML = `<div class="error"><span>⚠️</span>Invalid Date! Future date not allowed.</div>`;
    return;
  }

  // calculate age
  let ageYears = today.getFullYear() - birthDate.getFullYear();
  let ageMonths = today.getMonth() - birthDate.getMonth();
  let ageDays = today.getDate() - birthDate.getDate();

  // adjust months and days
  if (ageDays < 0) {
    ageMonths--;
    ageDays += new Date(today.getFullYear(), today.getMonth(), 0).getDate();
  }

  if (ageMonths < 0) {
    ageYears--;
    ageMonths += 12;
  }

  // final result
  result.innerHTML = `<p>Your Age is: <strong>${ageYears} Years, ${ageMonths} Months, ${ageDays} Days</strong></p>`;
}
